import React, { useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  Boxes,
  Cpu,
  Gauge,
  LockKeyhole,
  Network,
  Radar,
  ShieldCheck,
  Terminal,
  Server,
  Search,
  CheckCircle2,
  FileText,
  Download,
} from "lucide-react";

import {
  PolarAngleAxis,
  PolarGrid,
  RadarChart,
  Radar as RechartsRadar,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

const API_URL = "http://localhost:8000";

const emptyScan = {
  status: "idle",
  risk_score: 0,
  risk_level: "minimal",
  summary: {},
  findings: [],
  services: [],
  open_ports: [],
  closed_ports: [],
  filtered_ports: [],
  os_matches: [],
  addresses: [],
  hostnames: [],
  firewall: {
    detected: false,
    confidence: "none",
    reason: "",
  },
  architecture: {
    exposed_roles: [],
    detected_services: [],
    architecture_note: "",
  },
  risk_graph: {
    labels: [],
    values: [],
  },
};

function App() {
  const [activePage, setActivePage] = useState("overview");

  const [target, setTarget] = useState("");
  const [authorized, setAuthorized] = useState(false);

  const [scan, setScan] = useState(emptyScan);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [terminalCommand, setTerminalCommand] =
    useState("nmap -sV 127.0.0.1");

  const [terminalOutput, setTerminalOutput] = useState("");
  const [terminalLoading, setTerminalLoading] = useState(false);

  const graphData = useMemo(() => {
    return (scan.risk_graph?.labels || []).map((label, index) => ({
      subject: label,
      value: scan.risk_graph?.values?.[index] || 0,
      fullMark: 30,
    }));
  }, [scan]);

  const scoreColor =
    scan.risk_score >= 60
      ? "#ff5d6c"
      : scan.risk_score >= 35
      ? "#ffb84d"
      : "#44e3b1";

  async function startScan(event) {
    event.preventDefault();

    setError("");

    if (!target.trim()) {
      setError("Enter an IP address or hostname.");
      return;
    }

    if (!authorized) {
      setError("Confirm that you have permission to scan this target.");
      return;
    }

    setLoading(true);

    setScan({
      ...emptyScan,
      status: "queued",
    });

    try {
      const response = await fetch(`${API_URL}/api/scans`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          target: target.trim(),
          authorized: true,
          profile: "safe",
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Unable to create scan.");
      }

      await pollScan(data.scan_id);
    } catch (scanError) {
      setError(scanError.message);
      setLoading(false);
    }
  }

  async function pollScan(scanId) {
    try {
      const response = await fetch(`${API_URL}/api/scans/${scanId}`);

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Unable to fetch scan.");
      }

      setScan(data);

      if (
        data.status === "completed" ||
        data.status === "failed"
      ) {
        setLoading(false);
        return;
      }

      setTimeout(() => {
        pollScan(scanId);
      }, 900);
    } catch (scanError) {
      setError(scanError.message);
      setLoading(false);
    }
  }

  async function runNmapCommand(event) {
    event.preventDefault();

    if (!terminalCommand.trim()) {
      return;
    }

    setTerminalLoading(true);
    setTerminalOutput("");

    try {
      const response = await fetch(`${API_URL}/api/tools/nmap`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          command: terminalCommand.trim(),
          authorized: true,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Nmap command failed.");
      }

      setTerminalOutput(data.output || "No output returned.");
    } catch (terminalError) {
      setTerminalOutput(`ERROR: ${terminalError.message}`);
    } finally {
      setTerminalLoading(false);
    }
  }

  function renderPage() {
    switch (activePage) {
      case "network":
        return (
          <NetworkMap
            target={target}
            scan={scan}
          />
        );

      case "findings":
        return <FindingsPage scan={scan} />;

      case "policies":
        return <PoliciesPage />;

      case "terminal":
        return (
          <TerminalPage
            terminalCommand={terminalCommand}
            setTerminalCommand={setTerminalCommand}
            terminalOutput={terminalOutput}
            terminalLoading={terminalLoading}
            runNmapCommand={runNmapCommand}
          />
        );

      case "report":
        return <AssessmentReport scan={scan} target={target} />;

      default:
        return (
          <OverviewPage
            target={target}
            setTarget={setTarget}
            authorized={authorized}
            setAuthorized={setAuthorized}
            scan={scan}
            loading={loading}
            error={error}
            startScan={startScan}
            graphData={graphData}
            scoreColor={scoreColor}
          />
        );
    }
  }

  return (
    <main className="app-shell">

      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />

      {/* SIDEBAR */}

      <aside className="sidebar">

        <div className="brand">

          <div className="brand-mark">
            <Radar size={22} />
          </div>

          <div>
            <strong>VECTORSCAN</strong>
            <span>Developed by Keya</span>
          </div>

        </div>

        <nav className="nav">

          <button
            className={`nav-item ${
              activePage === "overview" ? "active" : ""
            }`}
            onClick={() => setActivePage("overview")}
          >
            <Gauge size={18} />
            <span>Overview</span>
          </button>

          <button
            className={`nav-item ${
              activePage === "network" ? "active" : ""
            }`}
            onClick={() => setActivePage("network")}
          >
            <Network size={18} />
            <span>Network map</span>
          </button>

          <button
            className={`nav-item ${
              activePage === "findings" ? "active" : ""
            }`}
            onClick={() => setActivePage("findings")}
          >
            <AlertTriangle size={18} />
            <span>Findings</span>

            {scan.findings?.length > 0 && (
              <small>{scan.findings.length}</small>
            )}
          </button>

          <button
            className={`nav-item ${
              activePage === "policies" ? "active" : ""
            }`}
            onClick={() => setActivePage("policies")}
          >
            <LockKeyhole size={18} />
            <span>Policies</span>
          </button>

          <button
            className={`nav-item ${
              activePage === "terminal" ? "active" : ""
            }`}
            onClick={() => setActivePage("terminal")}
          >
            <Terminal size={18} />
            <span>Nmap Terminal</span>
          </button>

          <button
            className={`nav-item ${
              activePage === "report" ? "active" : ""
            }`}
            onClick={() => setActivePage("report")}
          >
            <FileText size={18} />
            <span>Assessment report</span>
          </button>

        </nav>

        <div className="sidebar-status">

          <span className="status-dot" />

          Scanner engine online

          <small>
            safe profile / v1.0
          </small>

        </div>

      </aside>

      {/* MAIN CONTENT */}

      <section className="content">

        <header className="topbar">

          <div>

            <span className="eyebrow">
              AUTHORIZED SECURITY OPERATIONS
            </span>

            <h1>
              Network exposure intelligence
            </h1>

          </div>

          <div className="system-chip">

            <Cpu size={16} />

            LOCAL ENGINE

          </div>

        </header>

        {renderPage()}

      </section>

    </main>
  );
}


/* =========================================================
   OVERVIEW
========================================================= */

function OverviewPage({
  target,
  setTarget,
  authorized,
  setAuthorized,
  scan,
  loading,
  error,
  startScan,
  graphData,
  scoreColor,
}) {
  return (
    <>
      <section className="hero-grid">

        {/* SCAN CARD */}

        <div className="scan-card panel">

          <div className="panel-label">

            <Terminal size={16} />

            COMMAND CENTER

          </div>

          <h2>
            Map the attack surface.
          </h2>

          <p className="muted">
            Run a controlled, non-destructive assessment
            against an authorized IP address or hostname.
          </p>

          <form onSubmit={startScan}>

            <label htmlFor="target">
              Target address
            </label>

            <div className="target-input">

              <span>://</span>

              <input
                id="target"
                value={target}
                onChange={(event) =>
                  setTarget(event.target.value)
                }
                placeholder="192.168.1.10"
              />

              <span className="input-status">
                READY
              </span>

            </div>

            <label className="authorization">

              <input
                type="checkbox"
                checked={authorized}
                onChange={(event) =>
                  setAuthorized(event.target.checked)
                }
              />

              <span>
                I have authorization to assess this target.

                <small>
                  Safe scan only. No exploitation or
                  credential attacks.
                </small>
              </span>

            </label>

            {error && (
              <div className="error">
                {error}
              </div>
            )}

            <button
              className="scan-button"
              disabled={loading}
            >

              <Activity size={18} />

              {loading
                ? "SCANNING TARGET"
                : "INITIATE SAFE SCAN"}

            </button>

          </form>

        </div>


        {/* NETWORK VISUAL */}

        <div className="network-visual panel">

          <div className="grid-lines" />

          <div className="visual-label">
            LIVE TOPOLOGY /{" "}
            {scan.status?.toUpperCase() || "IDLE"}
          </div>

          <div
            className={`orbit ${
              loading ? "orbiting" : ""
            }`}
          >

            <div className="orbit-ring ring-one" />
            <div className="orbit-ring ring-two" />
            <div className="orbit-ring ring-three" />

            {/* SPACE ANIMATION */}

            <div className="space">

              <span className="star star-1" />
              <span className="star star-2" />
              <span className="star star-3" />
              <span className="star star-4" />
              <span className="star star-5" />
              <span className="star star-6" />

              <span className="planet planet-one" />
              <span className="planet planet-two" />

              <span className="comet" />

            </div>

            <div className="core">

              <ShieldCheck size={30} />

              <span>
                {loading ? "ACTIVE" : "IDLE"}
              </span>

            </div>

            <div className="node node-one" />
            <div className="node node-two" />
            <div className="node node-three" />
            <div className="node node-four" />

          </div>

          <div className="telemetry">

            <span>PACKETS</span>

            <strong>
              {loading
                ? "STREAMING"
                : "STANDBY"}
            </strong>

          </div>

        </div>

      </section>


      {/* METRICS */}

      <section className="metrics-grid">

        <Metric
          title="Risk score"
          value={scan.risk_score || 0}
          suffix="/100"
          icon={<Gauge />}
          color={scoreColor}
        />

        <Metric
          title="Open services"
          value={scan.services?.length || 0}
          icon={<Boxes />}
        />

        <Metric
          title="High severity"
          value={scan.summary?.high || 0}
          icon={<AlertTriangle />}
          color="#ff5d6c"
        />

        <Metric
          title="Scan state"
          value={scan.status || "idle"}
          icon={<Activity />}
        />

      </section>


      {/* RESULTS */}

      <section className="results-grid">

        {/* RADAR */}

        <div className="panel chart-panel">

          <div className="panel-heading">

            <div>

              <span className="eyebrow">
                RISK TELEMETRY
              </span>

              <h3>
                Exposure profile
              </h3>

            </div>

            <span
              className="risk-level"
              style={{
                color: scoreColor,
              }}
            >
              {scan.risk_level || "minimal"}
            </span>

          </div>

          <div className="chart-wrap">

            {graphData.length ? (

              <ResponsiveContainer
                width="100%"
                height="100%"
              >

                <RadarChart
                  data={graphData}
                >

                  <PolarGrid
                    stroke="#24434d"
                  />

                  <PolarAngleAxis
                    dataKey="subject"
                    stroke="#8ca5aa"
                    tick={{
                      fontSize: 12,
                    }}
                  />

                  <Tooltip
                    contentStyle={{
                      background: "#101b20",
                      border:
                        "1px solid #2d535b",
                      color: "#fff",
                    }}
                  />

                  <RechartsRadar
                    dataKey="value"
                    stroke="#44e3b1"
                    fill="#44e3b1"
                    fillOpacity={0.22}
                  />

                </RadarChart>

              </ResponsiveContainer>

            ) : (

              <div className="empty-state">

                <Radar size={32} />

                <span>
                  Run a scan to populate
                  the exposure profile.
                </span>

              </div>

            )}

          </div>

        </div>


        {/* FINDINGS */}

        <div className="panel findings-panel">

          <div className="panel-heading">

            <div>

              <span className="eyebrow">
                SECURITY FINDINGS
              </span>

              <h3>
                Detected conditions
              </h3>

            </div>

            <span className="finding-count">
              {scan.findings?.length || 0} ITEMS
            </span>

          </div>

          <div className="findings-list">

            {scan.findings?.length ? (

              scan.findings.map((finding, index) => (

                <div
                  className="finding"
                  key={
                    finding.id ||
                    `${finding.port}-${index}`
                  }
                >

                  <div
                    className={`severity ${
                      finding.severity || "medium"
                    }`}
                  >
                    {finding.severity || "MEDIUM"}
                  </div>

                  <div className="finding-content">

                    <strong>
                      {finding.title ||
                        "Security finding"}
                    </strong>

                    <p>
                      {finding.description ||
                        "Potential security condition detected."}
                    </p>

                    <small>
                      {finding.port
                        ? `PORT ${finding.port}`
                        : "CONFIGURATION"}
                    </small>

                  </div>

                </div>

              ))

            ) : (

              <div className="empty-findings">

                <ShieldCheck size={25} />

                <span>
                  No findings available.
                </span>

              </div>

            )}

          </div>

        </div>

      </section>
    </>
  );
}


/* =========================================================
   NETWORK MAP
========================================================= */

function NetworkMap({ target, scan }) {
  const services = scan.services || [];

  return (
    <section className="page-panel">

      <div className="panel-heading">

        <div>

          <span className="eyebrow">
            NETWORK INTELLIGENCE
          </span>

          <h2>
            Network map
          </h2>

        </div>

        <span className="risk-level">
          {scan.status?.toUpperCase() || "IDLE"}
        </span>

      </div>

      <div className="network-map-large">

        <div className="network-center">

          <ShieldCheck size={36} />

          <strong>
            {target || "NO TARGET"}
          </strong>

          <small>
            SCAN TARGET
          </small>

        </div>

        {services.length > 0 ? (

          services.map((service, index) => (

            <div
              className={`network-service service-${
                index % 6
              }`}
              key={`${service.port}-${index}`}
            >

              <Network size={18} />

              <strong>
                {service.name || "Service"}
              </strong>

              <span>
                PORT {service.port}
              </span>

              {service.version && (
                <small>
                  {service.version}
                </small>
              )}

            </div>

          ))

        ) : (

          <div className="empty-state">

            <Network size={32} />

            <p>
              Run a scan to populate
              the network map.
            </p>

          </div>

        )}

      </div>

      <div className="network-summary-grid">

        <div className="panel mini-card">

          <Server size={20} />

          <span>
            DISCOVERED SERVICES
          </span>

          <strong>
            {services.length}
          </strong>

        </div>

        <div className="panel mini-card">

          <Activity size={20} />

          <span>
            SCAN STATUS
          </span>

          <strong>
            {scan.status || "idle"}
          </strong>

        </div>

        <div className="panel mini-card">

          <Gauge size={20} />

          <span>
            RISK SCORE
          </span>

          <strong>
            {scan.risk_score || 0}
          </strong>

        </div>

      </div>

    </section>
  );
}


/* =========================================================
   FINDINGS
========================================================= */

function FindingsPage({ scan }) {
  const findings = scan.findings || [];

  return (
    <section className="page-panel">

      <div className="panel-heading">

        <div>

          <span className="eyebrow">
            SECURITY ANALYSIS
          </span>

          <h2>
            Security findings
          </h2>

        </div>

        <span className="finding-count">
          {findings.length} ITEMS
        </span>

      </div>

      <div className="findings-list findings-page-list">

        {findings.length > 0 ? (

          findings.map((finding, index) => (

            <div
              className="finding finding-large"
              key={
                finding.id ||
                `${finding.port}-${index}`
              }
            >

              <div
                className={`severity ${
                  finding.severity || "medium"
                }`}
              >
                {finding.severity || "MEDIUM"}
              </div>

              <div className="finding-content">

                <strong>
                  {finding.title ||
                    "Security finding"}
                </strong>

                <p>
                  {finding.description ||
                    "Potential security condition detected."}
                </p>

                <small>
                  {finding.port
                    ? `PORT ${finding.port}`
                    : "CONFIGURATION"}
                </small>

                {finding.recommendation && (

                  <div className="recommendation">

                    <strong>
                      Recommendation:
                    </strong>{" "}

                    {finding.recommendation}

                  </div>

                )}

              </div>

            </div>

          ))

        ) : (

          <div className="empty-findings">

            <ShieldCheck size={34} />

            <h3>
              No security findings
            </h3>

            <p>
              Run a scan to analyze the target.
            </p>

          </div>

        )}

      </div>

    </section>
  );
}


/* =========================================================
   ASSESSMENT REPORT
========================================================= */

function AssessmentReport({ scan, target }) {
  const findings = scan.findings || [];
  const services = (scan.services || []).filter(
    (service) => service.state === "open"
  );

  const openPorts = scan.open_ports || [];
  const closedPorts = scan.closed_ports || [];
  const filteredPorts = scan.filtered_ports || [];
  const osMatches = scan.os_matches || [];
  const firewall = scan.firewall || {};
  const architecture = scan.architecture || {};
  const summary = scan.summary || {};

  function downloadReport() {
    const report = {
      product: "VECTORSCAN",
      report_type: "Network Security Assessment",
      target: target || scan.target || "",
      status: scan.status || "unknown",
      risk_score: scan.risk_score || 0,
      risk_level: scan.risk_level || "minimal",
      summary,
      open_ports: openPorts,
      closed_ports: closedPorts,
      filtered_ports: filteredPorts,
      services,
      operating_system: osMatches,
      firewall,
      architecture,
      findings,
    };

    const blob = new Blob(
      [JSON.stringify(report, null, 2)],
      { type: "application/json" }
    );

    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `vectorscan-report-${target || "target"}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <section className="page-panel">
      <div className="panel-heading">
        <div>
          <span className="eyebrow">
            SECURITY ASSESSMENT
          </span>
          <h2>Network security report</h2>
          <p className="muted">
            Structured assessment generated from the latest authorized scan.
          </p>
        </div>

        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          <button
            type="button"
            className="scan-button"
            onClick={() => window.print()}
            disabled={scan.status !== "completed"}
          >
            <FileText size={16} />
            PRINT / SAVE PDF
          </button>

          <button
            type="button"
            className="scan-button"
            onClick={downloadReport}
            disabled={scan.status !== "completed"}
          >
            <Download size={16} />
            EXPORT JSON
          </button>
        </div>
      </div>

      {scan.status !== "completed" ? (
        <div className="empty-state">
          <FileText size={34} />
          <h3>No completed assessment</h3>
          <p>Run a scan first to generate the assessment report.</p>
        </div>
      ) : (
        <>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))",
              gap: "12px",
              marginBottom: "18px",
            }}
          >
            <ReportStat
              label="TARGET"
              value={target || scan.target || "Unknown"}
            />
            <ReportStat
              label="RISK SCORE"
              value={`${scan.risk_score || 0}/100`}
            />
            <ReportStat
              label="RISK LEVEL"
              value={(scan.risk_level || "minimal").toUpperCase()}
            />
            <ReportStat label="OPEN PORTS" value={openPorts.length} />
            <ReportStat label="SERVICES" value={services.length} />
            <ReportStat label="FINDINGS" value={findings.length} />
          </div>

          <ReportSection title="Port discovery">
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
                gap: "10px",
              }}
            >
              <ReportStat
                label="OPEN"
                value={openPorts.join(", ") || "None"}
              />
              <ReportStat label="CLOSED" value={closedPorts.length} />
              <ReportStat label="FILTERED" value={filteredPorts.length} />
            </div>
          </ReportSection>

          <ReportSection title="Detected services">
            {services.length ? (
              <div style={{ overflowX: "auto" }}>
                <table
                  style={{
                    width: "100%",
                    borderCollapse: "collapse",
                    fontSize: "13px",
                  }}
                >
                  <thead>
                    <tr>
                      <ReportTh>Port</ReportTh>
                      <ReportTh>Protocol</ReportTh>
                      <ReportTh>Service</ReportTh>
                      <ReportTh>Product</ReportTh>
                      <ReportTh>Version</ReportTh>
                    </tr>
                  </thead>
                  <tbody>
                    {services.map((service, index) => (
                      <tr key={`${service.port}-${index}`}>
                        <ReportTd>{service.port}</ReportTd>
                        <ReportTd>{service.protocol || "tcp"}</ReportTd>
                        <ReportTd>{service.name || "unknown"}</ReportTd>
                        <ReportTd>{service.product || "—"}</ReportTd>
                        <ReportTd>{service.version || "—"}</ReportTd>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="muted">No open services were detected.</p>
            )}
          </ReportSection>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
              gap: "14px",
            }}
          >
            <ReportSection title="Operating system">
              {osMatches.length ? (
                osMatches.slice(0, 5).map((os, index) => (
                  <div
                    key={`${os.name}-${index}`}
                    style={{
                      padding: "10px 0",
                      borderBottom: "1px solid rgba(255,255,255,0.08)",
                    }}
                  >
                    <strong>{os.name}</strong>
                    <span
                      style={{
                        display: "block",
                        marginTop: "4px",
                        opacity: 0.65,
                        fontSize: "12px",
                      }}
                    >
                      Fingerprint accuracy: {os.accuracy || "—"}%
                    </span>
                  </div>
                ))
              ) : (
                <p className="muted">
                  OS fingerprint was not available.
                </p>
              )}
            </ReportSection>

            <ReportSection title="Network filtering">
              <strong>
                {firewall.detected
                  ? "Possible filtering detected"
                  : "No strong filtering pattern detected"}
              </strong>
              <p className="muted">
                Confidence: {(firewall.confidence || "none").toUpperCase()}
              </p>
              <p className="muted">
                {firewall.reason || "No additional filtering evidence."}
              </p>
            </ReportSection>
          </div>

          <ReportSection title="Inferred network architecture">
            {architecture.exposed_roles?.length ? (
              <div
                style={{
                  display: "flex",
                  flexWrap: "wrap",
                  gap: "8px",
                  marginBottom: "10px",
                }}
              >
                {architecture.exposed_roles.map((role) => (
                  <span
                    key={role}
                    style={{
                      border: "1px solid rgba(68, 227, 177, 0.35)",
                      padding: "7px 10px",
                      borderRadius: "5px",
                      fontSize: "12px",
                    }}
                  >
                    {role}
                  </span>
                ))}
              </div>
            ) : (
              <p className="muted">
                No specific exposed role could be inferred.
              </p>
            )}

            <p className="muted">
              {architecture.architecture_note ||
                "Architecture is inferred from network-visible services."}
            </p>
          </ReportSection>

          <ReportSection title="Security findings">
            {findings.length ? (
              <div style={{ display: "grid", gap: "10px" }}>
                {findings.map((finding, index) => (
                  <div
                    key={finding.id || index}
                    style={{
                      padding: "14px",
                      border: "1px solid rgba(255,255,255,0.08)",
                      borderRadius: "6px",
                      background: "rgba(0,0,0,0.14)",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        gap: "10px",
                        flexWrap: "wrap",
                      }}
                    >
                      <strong>
                        {finding.title || "Security finding"}
                      </strong>
                      <span>
                        {(finding.severity || "info").toUpperCase()}
                      </span>
                    </div>

                    <p className="muted">
                      {finding.description ||
                        "No description available."}
                    </p>

                    {finding.port && (
                      <small>PORT {finding.port}</small>
                    )}

                    {finding.evidence && (
                      <div
                        style={{
                          marginTop: "8px",
                          fontSize: "12px",
                          opacity: 0.8,
                        }}
                      >
                        <strong>Evidence:</strong>{" "}
                        {typeof finding.evidence === "object"
                          ? JSON.stringify(finding.evidence)
                          : String(finding.evidence)}
                      </div>
                    )}

                    {finding.recommendation && (
                      <div
                        style={{
                          marginTop: "8px",
                          fontSize: "12px",
                        }}
                      >
                        <strong>Recommendation:</strong>{" "}
                        {finding.recommendation}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="muted">
                No security findings were reported.
              </p>
            )}
          </ReportSection>

          <ReportSection title="Severity summary">
            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(130px, 1fr))",
                gap: "10px",
              }}
            >
              <ReportStat label="CRITICAL" value={summary.critical || 0} />
              <ReportStat label="HIGH" value={summary.high || 0} />
              <ReportStat label="MEDIUM" value={summary.medium || 0} />
              <ReportStat label="LOW" value={summary.low || 0} />
              <ReportStat label="INFO" value={summary.info || 0} />
            </div>
          </ReportSection>
        </>
      )}
    </section>
  );
}

function ReportSection({ title, children }) {
  return (
    <div
      className="panel"
      style={{
        marginBottom: "14px",
        padding: "18px",
      }}
    >
      <div className="panel-heading">
        <h3>{title}</h3>
      </div>
      {children}
    </div>
  );
}

function ReportStat({ label, value }) {
  return (
    <div className="panel" style={{ padding: "14px" }}>
      <span className="eyebrow">{label}</span>
      <strong
        style={{
          display: "block",
          marginTop: "7px",
          wordBreak: "break-word",
        }}
      >
        {value}
      </strong>
    </div>
  );
}

function ReportTh({ children }) {
  return (
    <th
      style={{
        textAlign: "left",
        padding: "10px",
        borderBottom: "1px solid rgba(255,255,255,0.12)",
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </th>
  );
}

function ReportTd({ children }) {
  return (
    <td
      style={{
        padding: "10px",
        borderBottom: "1px solid rgba(255,255,255,0.07)",
      }}
    >
      {children}
    </td>
  );
}


/* =========================================================
   POLICIES
========================================================= */

function PoliciesPage() {
  const policies = [
    {
      icon: <ShieldCheck size={22} />,
      title: "Authorized scanning",
      description:
        "Scanning is allowed only when the operator confirms authorization.",
    },
    {
      icon: <LockKeyhole size={22} />,
      title: "Non-destructive assessment",
      description:
        "Safe assessment profile prevents exploitation and credential attacks.",
    },
    {
      icon: <Network size={22} />,
      title: "Network exposure monitoring",
      description:
        "Track exposed services and identify risky network configurations.",
    },
    {
      icon: <AlertTriangle size={22} />,
      title: "Risk prioritization",
      description:
        "Findings are grouped according to severity and potential exposure.",
    },
  ];

  return (
    <section className="page-panel">

      <div className="panel-heading">

        <div>

          <span className="eyebrow">
            SECURITY GOVERNANCE
          </span>

          <h2>
            Security policies
          </h2>

        </div>

        <span className="policy-count">
          4 ACTIVE
        </span>

      </div>

      <div className="policy-grid">

        {policies.map((policy, index) => (

          <div
            className="policy-card"
            key={index}
          >

            <div className="policy-icon">
              {policy.icon}
            </div>

            <div className="policy-content">

              <strong>
                {policy.title}
              </strong>

              <p>
                {policy.description}
              </p>

            </div>

            <span className="policy-status enabled">

              <CheckCircle2 size={14} />

              ENABLED

            </span>

          </div>

        ))}

      </div>

    </section>
  );
}


/* =========================================================
   NMAP TERMINAL
========================================================= */

function TerminalPage({
  terminalCommand,
  setTerminalCommand,
  terminalOutput,
  terminalLoading,
  runNmapCommand,
}) {
  return (
    <section className="page-panel terminal-page">

      <div className="panel-heading">

        <div>

          <span className="eyebrow">
            SECURITY TOOLING
          </span>

          <h2>
            Nmap terminal
          </h2>

          <p className="muted">
            Execute authorized Nmap reconnaissance
            commands through the local scanner engine.
          </p>

        </div>

        <div className="terminal-badge">

          <Terminal size={16} />

          LOCAL NMAP

        </div>

      </div>

      <form
        className="terminal-form"
        onSubmit={runNmapCommand}
      >

        <div className="terminal-input">

          <span>
            $
          </span>

          <input
            value={terminalCommand}
            onChange={(event) =>
              setTerminalCommand(
                event.target.value
              )
            }
            placeholder="nmap -sV 127.0.0.1"
          />

          <button
            type="submit"
            disabled={terminalLoading}
          >

            <Search size={17} />

            {terminalLoading
              ? "RUNNING"
              : "RUN NMAP"}

          </button>

        </div>

      </form>

      <div className="terminal-window">

        <div className="terminal-header">

          <span className="terminal-dot red" />
          <span className="terminal-dot yellow" />
          <span className="terminal-dot green" />

          <span className="terminal-title">
            vectorscan@nmap
          </span>

        </div>

        <pre className="terminal-output">

          {terminalLoading
            ? "Running Nmap...\n"
            : terminalOutput ||
              "Nmap terminal ready.\n\nEnter an authorized Nmap command above."}

        </pre>

      </div>

      <div className="terminal-help">

        <div>

          <strong>
            Common commands
          </strong>

          <code>
            nmap -sV 127.0.0.1
          </code>

          <code>
            nmap -sS 127.0.0.1
          </code>

          <code>
            nmap -p 22,80,443 127.0.0.1
          </code>

        </div>

      </div>

    </section>
  );
}


/* =========================================================
   METRIC
========================================================= */

function Metric({
  title,
  value,
  suffix,
  icon,
  color,
}) {
  return (
    <div className="metric panel">

      <div className="metric-icon">
        {icon}
      </div>

      <span>
        {title}
      </span>

      <strong
        style={{
          color,
        }}
      >

        {value}

        {suffix && (
          <small>
            {suffix}
          </small>
        )}

      </strong>

    </div>
  );
}

export default App;